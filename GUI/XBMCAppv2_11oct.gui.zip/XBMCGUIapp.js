/* XBMC View for CommandFusion
===============================================================================

AUTHOR:		Jarrod Bell, CommandFusion
CONTACT:	support@commandfusion.com
URL:		https://github.com/CommandFusion/
VERSION:	v0.0.1

Tested on XBMC Night Version XBMC Night pre-11.0 (released Aug 3 2011)
=========================================================================
HELP:

This script is used to separate the XBMC GUI interaction from the XBMC controller

=========================================================================
*/

// ======================================================================
// Global Object
// ======================================================================

var XBMC_GUI = function(params) {
	var self = {
		// XBMC Instance
		XBMC:						null,
		//Menu button joins
		joinbtnTVShows: 			10,
		joinbtnMovies: 				11,
		joinbtnMusic: 				12,
		joinbtnPlayingNow: 			13,
		joinbtnPlaylist: 			14,
		
		//Dropdown Menu Subpage joins
		joinmenuTVShowsMain:		20,
		joinmenuTVShowsOrder:		21,
		joinmenuTVShowsAscend:		22,
		joinmenuTVShowsDescend:		23,
		
		
		// GUI definitions
		joinTVShows:				3001,
		joinTVSeasons:				3002,
		joinTVEpisodes:				3003,
		joinRecentEpisodes:			3004,
		joinTVShowsGenre:			3005,
		joinTVShowsGenreDetails:	3006,
		joinTVEpisodeDetails:		4001,
		joinMute:					2999,
		joinMovies:					1001,
		joinMovieWall:				1002,
		joinRecentMovies:			1003,
		joinMoviesGenre:			1004,
		joinMoviesGenreDetails:		1005,
		joinMovieDetails:   		2001,
		joinMusicArtist: 			5001,
		joinMusicAlbum: 			5002,
		joinMusicSong: 				5003,
		joinRecentAlbums:			5004,
		joinRecentSongs:			5005,
		joinMusicDetails:			6001,
		joinNowPlaying: 			8000,
		joinCurrentAudioPlaylist: 	8001,
		joinCurrentVideoPlaylist: 	8101,
		//joinNowPlayingAudio: 		8002,
		//joinNowPlayingVideoEpisode:8003,
		//joinNowPlayingVideoMovie:	8004,
		joinFileList: 				9001
		//joinRecentAdded: 			9501,
		//joinRecentAddedEpisodes: 	9601,
		//joinRecentAddedMovies: 		9701,
		//joinRecentAddedAlbums: 		9801,
		//joinRecentAddedSongs: 		9901
		
	};

		
	self.setup = function() {
		
		// On startup, check for global tokens via CF.getJoin(CF.GlobalTokensJoin)
		// submit the value to the system via CF.setSystemProperties, updating the current IP address of the system
		
		
		
		// Shows subpages automatically
		CF.setJoin("d"+self.joinTVShows, 1);		// TV Show subpage
		CF.setJoin("d"+self.joinTVSeasons, 0);		// Show TV Seasons list
		CF.setJoin("d"+self.joinTVEpisodes, 0);		// Show TV Episodes list
			
		CF.setJoin("d"+self.joinMovies, 1);					// Movie subpage
		CF.setJoin("d"+self.joinMusicArtist, 1);			// Music Artist subpage
		//CF.setJoin("d"+self.joinRecentAdded, 1);			// Recently Added Subpage
		
		CF.setJoin("d"+self.joinbtnTVShows, 1);				// Show active icon for default page (TV Show)
		
		// Shows list 
		CF.setJoin("d"+self.joinCurrentAudioPlaylist, 1);	// Playlist Page - Audio Playlist list
		CF.setJoin("d"+self.joinCurrentVideoPlaylist, 1);	// Playlist Page - Video Playlist list
		CF.setJoin("d"+self.joinFileList, 1);				// File Page - File list
		
		// Call the setup function on the XBMC instance
		self.XBMC.setup();
		
		// Get volume state on startup
		self.volGet();

		// Request the initial list 
		self.XBMC.getTVShows(self.joinTVShows, "ascending", "label");		// TV Show function (subpage join, sort order, method). By default, sort is ascending and by label
		self.XBMC.getMovies(self.joinMovies, "ascending", "label");				// Movies
		self.XBMC.getMusicArtist(self.joinMusicArtist, "ascending", "label");	// Artists
		//self.XBMC.getAudioPlaylist(self.joinCurrentAudioPlaylist);			// Audio Playlist
		//self.XBMC.getVideoPlaylist(self.joinCurrentVideoPlaylist);			// Video Playlist
		//self.XBMC.getRecentAlbums(self.joinRecentAddedAlbums);				// Recently Added Albums
		//self.XBMC.getRecentEpisodes(self.joinRecentAddedEpisodes);			// Recently Added Episodes
		//self.XBMC.getRecentMovies(self.joinRecentAddedMovies);				// Recently Added Movies
		//self.XBMC.getRecentSongs(self.joinRecentAddedSongs);					// Recently Added Songs 
		
	};
	
	//--------------------------------------------------------------------------------------------------
	// Toggling subpages & Selection for TV Shows
	//--------------------------------------------------------------------------------------------------
	
	self.selectTVShow = function(list, listIndex, join) {			
			CF.getJoin(list+":"+listIndex+":"+join, function(j,v,t) {
			CF.setJoin("d"+self.joinTVShows, 0);				// TV Show subpage
			CF.setJoin("d"+self.joinTVSeasons, 1);			// Show TV Seasons list
			CF.setJoin("d"+self.joinTVEpisodes, 0);		// Show TV Episodes list
			CF.setJoin("d"+self.joinRecentEpisodes, 0);		// Show Recently Added Episodes list
			CF.setJoin("d"+self.joinTVShowsGenre, 0);		// Show Genre list's subpage
			CF.setJoin("d"+self.joinTVShowsGenreDetails, 0);	// Show Genre detail's subpage
			
			self.XBMC.getTVSeasons(t["[id]"],t["[showname]"],self.joinTVSeasons); 	// Get TV Seasons
		});
	};

	self.selectTVSeason = function(list, listIndex, join) {
		CF.getJoin(list+":"+listIndex+":"+join, function(j,v,t) {
			CF.setJoin("d"+self.joinTVEpisodes, 1);														// Show TV Episodes list
			self.XBMC.getTVEpisodes(t["[id]"], t["[season]"], t["[showtitle]"], self.joinTVEpisodes); 	// Get TV Episodes
		});
	};

	self.selectTVEpisode = function(list, listIndex, join) {
		CF.getJoin(list+":"+listIndex+":"+join, function(j,v,t) {
			self.XBMC.getTVEpisodeDetails(t["[id]"], self.joinTVEpisodeDetails);		// Get TV Episodes Details
		});
	};
	
	self.showSeries = function() {
		CF.setJoin("d"+self.joinTVShows, 1);			// TV Show subpage
		CF.setJoin("d"+self.joinTVSeasons, 0);			// Show TV Seasons list
		CF.setJoin("d"+self.joinTVEpisodes, 0);			// Show TV Episodes list
		CF.setJoin("d"+self.joinRecentEpisodes, 0);		// Show Recently Added Episodes list
		CF.setJoin("d"+self.joinTVShowsGenre, 0);		// Show Genre list's subpage
		CF.setJoin("d"+self.joinTVShowsGenreDetails, 0);	// Show Genre detail's subpage
	};
	
	self.showSeason = function() {
		CF.setJoin("d"+self.joinTVShows, 0);				// TV Show subpage
		CF.setJoin("d"+self.joinTVSeasons, 1);			// Show TV Seasons list
		CF.setJoin("d"+self.joinTVEpisodes, 0);		// Show TV Episodes list
		CF.setJoin("d"+self.joinRecentEpisodes, 0);		// Show Recently Added Episodes list
		CF.setJoin("d"+self.joinTVShowsGenre, 0);		// Show Genre list's subpage
		CF.setJoin("d"+self.joinTVShowsGenreDetails, 0);	// Show Genre detail's subpage
	};
	
	self.showEpisodes = function() {
		CF.setJoin("d"+self.joinTVShows, 0);			// TV Show subpage
		CF.setJoin("d"+self.joinTVSeasons, 0);			// Show TV Seasons list
		CF.setJoin("d"+self.joinTVEpisodes, 1);			// Show TV Episodes list
		CF.setJoin("d"+self.joinRecentEpisodes, 0);		// Show Recently Added Episodes list
		CF.setJoin("d"+self.joinTVShowsGenre, 0);		// Show Genre list's subpage
		CF.setJoin("d"+self.joinTVShowsGenreDetails, 0);	// Show Genre detail's subpage
	};
	
	self.sortTVShow = function(order, method) {
		CF.setJoin("d"+self.joinTVShows, 1);			// TV Show subpage
		CF.setJoin("d"+self.joinTVSeasons, 0);			// Show TV Seasons list
		CF.setJoin("d"+self.joinTVEpisodes, 0);			// Show TV Episodes list
		CF.setJoin("d"+self.joinRecentEpisodes, 0);		// Show Recently Added Episodes list
		CF.setJoin("d"+self.joinTVShowsGenre, 0);		// Show Genre list's subpage
		self.XBMC.getTVShows(self.joinTVShows, order, method);
	};
	
	self.TVShowSearch = function(search_string) {					// data passed is assigned as string_search
		self.XBMC.searchTVShows(search_string, self.joinTVShows);
	};
	
	self.RecentAddedEpisodes = function(){
		CF.setJoin("d"+self.joinTVShows, 0);			// TV Show subpage
		CF.setJoin("d"+self.joinTVSeasons, 0);			// Show TV Seasons list
		CF.setJoin("d"+self.joinTVEpisodes, 0);			// Show TV Episodes list
		CF.setJoin("d"+self.joinRecentEpisodes, 1);		// Show Recently Added Episodes list
		CF.setJoin("d"+self.joinTVShowsGenre, 0);		// Show Genre list's subpage
		CF.setJoin("d"+self.joinTVShowsGenreDetails, 0);	// Show Genre detail's subpage
		self.XBMC.getRecentEpisodes(self.joinRecentEpisodes);				// Get Recently Added Episodes
	};
	
	//self.getRecentEpisodesDetails = function(){
	//	self.XBMC.getTVEpisodeDetails(t["id"], self.joinTVEpisodeDetails);				// Get Recently Added Episodes details
	//};
	
	self.showTVShowsGenre = function(){
		CF.setJoin("d"+self.joinTVShows, 0);			// TV Show subpage
		CF.setJoin("d"+self.joinTVSeasons, 0);			// Show TV Seasons list
		CF.setJoin("d"+self.joinTVEpisodes, 0);			// Show TV Episodes list
		CF.setJoin("d"+self.joinRecentEpisodes, 0);		// Show Recently Added Episodes list
		CF.setJoin("d"+self.joinTVShowsGenre, 1);		// Show Genre list's subpage
		CF.setJoin("d"+self.joinTVShowsGenreDetails, 0);	// Show Genre detail's subpage
		
		self.XBMC.getTVShowsGenre(self.joinTVShowsGenre);				// Get Recently Added Episodes details
	};
	
	self.searchTVShowsGenre = function(list, listIndex, join){
		CF.getJoin(list+":"+listIndex+":"+join, function(j,v,t) {
		
			CF.setJoin("d"+self.joinTVShows, 0);				// TV Show subpage
			CF.setJoin("d"+self.joinTVSeasons, 0);				// Show TV Seasons list
			CF.setJoin("d"+self.joinTVEpisodes, 0);				// Show TV Episodes list
			CF.setJoin("d"+self.joinRecentEpisodes, 0);			// Show Recently Added Episodes list
			CF.setJoin("d"+self.joinTVShowsGenre, 0);			// Show Genre list's subpage
			CF.setJoin("d"+self.joinTVShowsGenreDetails, 1);	// Show Genre detail's subpage
		
			self.XBMC.getTVShowsGenreDetails(t["[genre]"], self.joinTVShowsGenreDetails);				// Get Recently Added Episodes details
		});
	};
	
	/*self.toggleTVShows = function(forceMode) {
		if (forceMode !== undefined) {
			// Use the forceMode to set a specific placement of the subpage
			if (forceMode == 1) {
				// Show the subpage
				CF.setProperties({join: "d"+self.joinTVShows, x: 0}, 0, 0.33, CF.AnimationCurveEaseOut);
				// Hide the browse bar
				CF.setProperties({join: "d"+(self.joinTVShows+100), opacity: 0.0}, 0, 0.33);
				// Move the episode details subpage over
				CF.setProperties({join: "d"+self.joinTVEpisode, x: 501}, 0.2, 0.15, CF.AnimationCurveEaseOut);
			} else {
				// Hide the subpage
				CF.setProperties({join: "d"+self.joinTVShows, x: -450}, 0, 0.33, CF.AnimationCurveEaseOut);
				// Show the browse bar
				CF.setProperties({join: "d"+(self.joinTVShows+100), opacity: 1.0}, 0, 0.33);
				// Move the episode details subpage back
				CF.setProperties({join: "d"+self.joinTVEpisode, x: 473}, 0, 0.33, CF.AnimationCurveEaseOut);
			}
		} else {
			// Automatically toggle the subpage location
			CF.getProperties("d"+self.joinTVShows, function(j) {
				if (j.x < 0) {
					// Item is off the page, so bring it back on
					CF.setProperties({join: j.join, x: 0}, 0, 0.33, CF.AnimationCurveEaseOut);
					// Hide the browse bar
					CF.setProperties({join: "d"+(self.joinTVShows+100), opacity: 0.0}, 0, 0.33);
					// Move the episode details subpage over
					CF.setProperties({join: "d"+self.joinTVEpisode, x: 501}, 0.2, 0.15, CF.AnimationCurveEaseOut);
				} else {
					// Item is on the page, so push it back off
					CF.setProperties({join: j.join, x: -450}, 0, 0.33, CF.AnimationCurveEaseOut);
					// Show the browse bar
					CF.setProperties({join: "d"+(self.joinTVShows+100), opacity: 1.0}, 0, 0.33);
					// Move the episode details subpage back
					CF.setProperties({join: "d"+self.joinTVEpisode, x: 473}, 0, 0.33, CF.AnimationCurveEaseOut);
				}
			});
		}
	};

	*/
	
	//--------------------------------------------------------------------------------------------------
	// Selection for Movies
	//--------------------------------------------------------------------------------------------------
	
	self.selectMovie = function(list, listIndex, join) {
		CF.getJoin(list+":"+listIndex+":"+join, function(j,v,t) {
			//Show MovieDetails subpage
			CF.setJoin("d"+self.joinMovieDetails, 1);
			CF.setJoin("d"+(self.joinMovieDetails+100), 0); // Hide blank subpage
			
			// Get TV Episode Details
			self.XBMC.getMovieDetails(t["[id]"], self.joinMovieDetails);
		});
	};
	
	self.sortMovie = function(order, method) {
		CF.setJoin("d"+self.joinMovies, 1);						// Show Movie list subpage	
		CF.setJoin("d"+self.joinMovieWall, 0);					// Hide Movie Wall subpage
		CF.setJoin("d"+self.joinRecentMovies, 0);				// Hide Recently Added Movie subpage
		CF.setJoin("d"+self.joinMoviesGenre, 0);				// Hide Movie Genre subpage
		CF.setJoin("d"+self.joinMoviesGenreDetails, 0);			// Hide Movie Genre Details subpage
		self.XBMC.getMovies(self.joinMovies, order, method); 	//sort and repopulate main Movie Array
	};
	
	self.searchMovie = function(search_string){
		
		CF.setJoin("d"+self.joinMovies, 1);						// Show Movie list subpage	
		CF.setJoin("d"+self.joinMovieWall, 0);					// Hide Movie Wall subpage
		CF.setJoin("d"+self.joinRecentMovies, 0);				// Hide Recently Added Movie subpage
		CF.setJoin("d"+self.joinMoviesGenre, 0);				// Hide Movie Genre subpage
		CF.setJoin("d"+self.joinMoviesGenreDetails, 0);			// Hide Movie Genre Details subpage
		
		self.XBMC.getSearchedMovieArray(search_string, self.joinMovies);
	};
	
	self.MovieList = function(){
		CF.setJoin("d"+self.joinMovies, 1);						// Show Movie list subpage	
		CF.setJoin("d"+self.joinMovieWall, 0);					// Hide Movie Wall subpage
		CF.setJoin("d"+self.joinRecentMovies, 0);				// Hide Recently Added Movie subpage
		CF.setJoin("d"+self.joinMoviesGenre, 0);				// Hide Movie Genre subpage
		CF.setJoin("d"+self.joinMoviesGenreDetails, 0);			// Hide Movie Genre Details subpage
	};
	
	self.MovieWall = function(){
		CF.setJoin("d"+self.joinMovies, 0);						// Hide Movie list subpage	
		CF.setJoin("d"+self.joinMovieWall, 1);					// Show Movie Wall subpage
		CF.setJoin("d"+self.joinRecentMovies, 0);				// Hide Recently Added Movie subpage
		CF.setJoin("d"+self.joinMoviesGenre, 0);				// Hide Movie Genre subpage
		CF.setJoin("d"+self.joinMoviesGenreDetails, 0);			// Hide Movie Genre Details subpage
		self.XBMC.buildMovieWall(self.joinMovies);			// Show the Movie Wall
	};
	
	self.recentAddMovies = function(){
		CF.setJoin("d"+self.joinMovies, 0);						// Show Movie list subpage	
		CF.setJoin("d"+self.joinMovieWall, 0);					// Hide Movie Wall subpage
		CF.setJoin("d"+self.joinRecentMovies, 1);				// Hide Recently Added Movie subpage
		CF.setJoin("d"+self.joinMoviesGenre, 0);				// Hide Movie Genre subpage
		CF.setJoin("d"+self.joinMoviesGenreDetails, 0);			// Hide Movie Genre Details subpage
		self.XBMC.getRecentMovies(self.joinMovies, "", "");				
	};
	
	self.showMoviesGenre = function(){
		CF.setJoin("d"+self.joinMovies, 0);						// Show Movie list subpage	
		CF.setJoin("d"+self.joinMovieWall, 0);					// Hide Movie Wall subpage
		CF.setJoin("d"+self.joinRecentMovies, 0);				// Hide Recently Added Movie subpage
		CF.setJoin("d"+self.joinMoviesGenre, 1);				// Hide Movie Genre subpage
		CF.setJoin("d"+self.joinMoviesGenreDetails, 0);			// Hide Movie Genre Details subpage
		
		self.XBMC.getMoviesGenre(self.joinMoviesGenre);				// Get Recently Added Episodes details
	};
	
	self.searchMoviesGenre = function(list, listIndex, join){
		CF.getJoin(list+":"+listIndex+":"+join, function(j,v,t) {
		
		CF.setJoin("d"+self.joinMovies, 0);						// Show Movie list subpage	
		CF.setJoin("d"+self.joinMovieWall, 0);					// Hide Movie Wall subpage
		CF.setJoin("d"+self.joinRecentMovies, 0);				// Hide Recently Added Movie subpage
		CF.setJoin("d"+self.joinMoviesGenre, 0);				// Hide Movie Genre subpage
		CF.setJoin("d"+self.joinMoviesGenreDetails, 1);			// Hide Movie Genre Details subpage
		
		self.XBMC.getMoviesGenreDetails(t["[genre]"], self.joinMoviesGenreDetails);				// Get Recently Added Episodes details
		});
	};
	
	
	
	//--------------------------------------------------------------------------------------------------
	// Toggling subpages & Selection for Music
	//--------------------------------------------------------------------------------------------------
	
	self.selectMusicArtist = function(list, listIndex, join) {
		CF.getJoin(list+":"+listIndex+":"+join, function(j,v,t) {
			CF.setJoin("d"+self.joinMusicAlbum, 1); 	// Show Music Album list
			CF.setJoin("d"+self.joinMusicDetails, 0);	// Hide Music Details subpage
			// Get Music Album list
			self.XBMC.getMusicAlbum(t["[id]"], t["[artist]"], self.joinMusicAlbum);
		});
	};

	self.selectMusicAlbum = function(list, listIndex, join) {
		CF.getJoin(list+":"+listIndex+":"+join, function(j,v,t) {
			
			CF.setJoin("d"+self.joinMusicArtist, 0);	// Show Artist subpage
			CF.setJoin("d"+self.joinMusicAlbum, 0);		// Hide Album subpage
			CF.setJoin("d"+self.joinMusicSong, 1);		// Hide Song subpage
			CF.setJoin("d"+self.joinRecentAlbums, 0);	// Hide Recently Added Albums subpage
			CF.setJoin("d"+self.joinRecentSongs, 0);	// Hide Recently Added Songs subpage
			
			// Get Music Song list
			self.XBMC.getMusicSong(t["[id]"], t["[artist]"], t["[albumtitle]"], self.joinMusicSong);
		});
	};

	self.selectMusicSong = function(list, listIndex, join) {
		CF.getJoin(list+":"+listIndex+":"+join, function(j,v,t) {
			CF.setJoin("d"+self.joinMusicSong, 1);
			// Get Music Details
			self.XBMC.getMusicDetails(t["[id]"],t["[file]"], self.joinMusicDetails);
			
			self.XBMC.playSong(t["file"]);				//Automatically play the song as press the song item instead of going to the details page.
			self.XBMC.addAudioPlaylist(t["file"]);		//Automatically add the song into the playlist as it's being played.
		});
	};
	
	self.addSongPlaylist = function(list, listIndex, join) {
		CF.getJoin(list+":"+listIndex+":"+join, function(j,v,t) {
			CF.setJoin("d"+self.joinMusicSong, 1);
			// Get Music Details
			self.XBMC.getMusicDetails(t["[id]"],t["[file]"], self.joinMusicDetails);
			
			self.XBMC.addAudioPlaylist(t["file"]); 		//Add into playlist by pessing the "Playlist" icon at the side of the song item list.
		});
	};
	
	self.showArtists = function() {
			CF.setJoin("d"+self.joinMusicArtist, 1);	// Show Artist subpage
			CF.setJoin("d"+self.joinMusicAlbum, 0);		// Hide Album subpage
			CF.setJoin("d"+self.joinMusicSong, 0);		// Hide Song subpage
			CF.setJoin("d"+self.joinRecentAlbums, 0);	// Hide Recently Added Albums subpage
			CF.setJoin("d"+self.joinRecentSongs, 0);			// Hide Recently Added Songs subpage
	};
	
	self.showAlbums = function() {
			CF.setJoin("d"+self.joinMusicArtist, 0);	// Hide Artist subpage
			CF.setJoin("d"+self.joinMusicAlbum, 1);		// Show Album subpage
			CF.setJoin("d"+self.joinMusicSong, 0);		// Hide Song subpage
			CF.setJoin("d"+self.joinRecentAlbums, 0);	// Hide Recently Added Albums subpage
			CF.setJoin("d"+self.joinRecentSongs, 0);			// Hide Recently Added Songs subpage
	};
	
	self.showSongs = function() {
			CF.setJoin("d"+self.joinMusicArtist, 0);	// Hide Artist subpage
			CF.setJoin("d"+self.joinMusicAlbum, 0);		// Show Album subpage
			CF.setJoin("d"+self.joinMusicSong, 1);		// Hide Song subpage
			CF.setJoin("d"+self.joinRecentAlbums, 0);	// Hide Recently Added Albums subpage
			CF.setJoin("d"+self.joinRecentSongs, 0);			// Hide Recently Added Songs subpage
	};
	
	self.sortArtist = function(order, method) {
		CF.setJoin("d"+self.joinMusicArtist, 1);	// Hide Artist subpage
			CF.setJoin("d"+self.joinMusicAlbum, 0);		// Show Album subpage
			CF.setJoin("d"+self.joinMusicSong, 0);		// Hide Song subpage
			CF.setJoin("d"+self.joinRecentAlbums, 0);	// Hide Recently Added Albums subpage
			CF.setJoin("d"+self.joinRecentSongs, 0);			// Hide Recently Added Songs subpage
		self.XBMC.getMusicArtist(self.joinMusicArtist, order, method);
	};
	
	self.ArtistSearch = function(search_string) {
		CF.setJoin("d"+self.joinMusicArtist, 1);	// Hide Artist subpage
			CF.setJoin("d"+self.joinMusicAlbum, 0);		// Show Album subpage
			CF.setJoin("d"+self.joinMusicSong, 0);		// Hide Song subpage
			CF.setJoin("d"+self.joinRecentAlbums, 0);	// Hide Recently Added Albums subpage
			CF.setJoin("d"+self.joinRecentSongs, 0);			// Hide Recently Added Songs subpage
		self.XBMC.searchArtist(search_string, self.joinMusicArtist);
	};
	
	self.recentAddAlbums = function(){
		CF.setJoin("d"+self.joinMusicArtist, 0);	// Hide Artist subpage
		CF.setJoin("d"+self.joinMusicAlbum, 0);		// Show Album subpage
		CF.setJoin("d"+self.joinMusicSong, 0);		// Hide Song subpage
		CF.setJoin("d"+self.joinRecentAlbums, 1);	// Hide Recently Added Albums subpage
		CF.setJoin("d"+self.joinRecentSongs, 0);			// Hide Recently Added Songs subpage
		self.XBMC.getRecentAlbums(self.joinRecentAlbums);				
	};
	
	self.recentAddSongs = function(){
		CF.setJoin("d"+self.joinMusicArtist, 0);	// Hide Artist subpage
		CF.setJoin("d"+self.joinMusicAlbum, 0);		// Show Album subpage
		CF.setJoin("d"+self.joinMusicSong, 0);		// Hide Song subpage
		CF.setJoin("d"+self.joinRecentAlbums, 0);	// Hide Recently Added Albums subpage
		CF.setJoin("d"+self.joinRecentSongs, 1);			// Hide Recently Added Songs subpage
		self.XBMC.getRecentSongs(self.joinRecentSongs);		// Movies
	};
	
		
	/*
	self.toggleMusicArtist = function(forceMode) {
		if (forceMode !== undefined) {
			// Use the forceMode to set a specific placement of the subpage
			if (forceMode == 1) {
				// Show the subpage
				CF.setProperties({join: "d"+self.joinMusicArtist, x: 0}, 0, 0.33, CF.AnimationCurveEaseOut);
				// Hide the browse bar
				CF.setProperties({join: "d"+(self.joinMusicArtist+100), opacity: 0.0}, 0, 0.33);
				// Move the episode details subpage over
				CF.setProperties({join: "d"+self.joinMusicDetails, x: 501}, 0.2, 0.15, CF.AnimationCurveEaseOut);
			} else {
				// Hide the subpage
				CF.setProperties({join: "d"+self.joinMusicArtist, x: -450}, 0, 0.33, CF.AnimationCurveEaseOut);
				// Show the browse bar
				CF.setProperties({join: "d"+(self.joinMusicArtist+100), opacity: 1.0}, 0, 0.33);
				// Move the episode details subpage back
				CF.setProperties({join: "d"+self.joinMusicDetails, x: 473}, 0, 0.33, CF.AnimationCurveEaseOut);
			}
		} else {
			// Automatically toggle the subpage location
			CF.getProperties("d"+self.joinMusicArtist, function(j) {
				if (j.x < 0) {
					// Item is off the page, so bring it back on
					CF.setProperties({join: j.join, x: 0}, 0, 0.33, CF.AnimationCurveEaseOut);
					// Hide the browse bar
					CF.setProperties({join: "d"+(self.joinMusicArtist+100), opacity: 0.0}, 0, 0.33);
					// Move the episode details subpage over
					CF.setProperties({join: "d"+self.joinMusicDetails, x: 501}, 0.2, 0.15, CF.AnimationCurveEaseOut);
				} else {
					// Item is on the page, so push it back off
					CF.setProperties({join: j.join, x: -450}, 0, 0.33, CF.AnimationCurveEaseOut);
					// Show the browse bar
					CF.setProperties({join: "d"+(self.joinMusicArtist+100), opacity: 1.0}, 0, 0.33);
					// Move the episode details subpage back
					CF.setProperties({join: "d"+self.joinMusicDetails, x: 473}, 0, 0.33, CF.AnimationCurveEaseOut);
				}
			});
		}
	};

	*/

	//--------------------------------------------------------------------------------------------------
	// Selection for Playlists & Sources
	//--------------------------------------------------------------------------------------------------
	
	self.NowPlaying = function() {
		self.XBMC.getNowPlaying(self.joinNowPlaying);
	};
	
	self.selectPlaylistFile = function(list, listIndex, join) {
		CF.getJoin(list+":"+listIndex+":"+join, function(j,v,t) {
			self.XBMC.playPlaylistFile(t["[file]"]);
		});
	};
	
	self.clearPlaylistAudio = function() {
		self.XBMC.clearAudioPlaylist(self.joinCurrentAudioPlaylist);
	};
	
	self.getPlaylistAudio = function() {
		self.XBMC.getAudioPlaylist(self.joinCurrentAudioPlaylist);
	};
	
	self.clearPlaylistVideo = function() {
		self.XBMC.clearVideoPlaylist(self.joinCurrentVideoPlaylist);
	};
	
	self.getPlaylistVideo = function() {
		self.XBMC.getVideoPlaylist(self.joinCurrentVideoPlaylist);
	};
	
	self.getAllPlaylist = function() {
		self.XBMC.getAudioPlaylist(self.joinCurrentAudioPlaylist);
		self.XBMC.getVideoPlaylist(self.joinCurrentVideoPlaylist);
	};
	
	self.clearAllPlaylist = function() {
		self.XBMC.clearAudioPlaylist(self.joinCurrentAudioPlaylist);
		self.XBMC.clearVideoPlaylist(self.joinCurrentVideoPlaylist);
	};
	
	self.getVideoSource = function() {
		self.XBMC.getSourceVideo(self.joinFileList);	
	};
	
	self.selectVideoDirectory = function(list, listIndex, join) {
		CF.getJoin(list+":"+listIndex+":"+join, function(j,v,t) {
			self.XBMC.getDirectoryVideo(t["[file]"], self.joinFileList);
		});
	};
	
	self.getMusicSource = function() {
		self.XBMC.getSourceMusic(self.joinFileList);	
	};
	
	self.getPictureSource = function() {
		self.XBMC.getSourcePicture(self.joinFileList);	
	};
	
	self.getFileSource = function() {
		self.XBMC.getSourceFile(self.joinFileList);	
	};
	
	self.getProgramSource = function() {
		self.XBMC.getSourceProgram(self.joinFileList);	
	};
		
		
	//--------------------------------------------------------------------------------------------------
	// Basic Control
	//--------------------------------------------------------------------------------------------------
		
	self.volGet = function() {
		self.XBMC.volGet(self.setMuteState);
	};

	self.volUp = function() {
		self.XBMC.volUp(self.setMuteState);
	};

	self.volDown = function() {
		self.XBMC.volDown(self.setMuteState);
	};

	self.volMute = function() {
		self.XBMC.volMute(self.setMuteState);
	};

	self.setMuteState = function() {
		CF.setJoin("d"+self.joinMute, self.XBMC.currentMute);
	};

	
	/*
	// ------------------------------------------------
	// Set everything up on object creation
	// ------------------------------------------------

	// Watch the system for feedback processing
	//\CF.watch(CF.FeedbackMatchedEvent, systemName, feedbackName, self.onIncomingData);

	// Watch the system connection status
	CF.watch(CF.ConnectionStatusChangeEvent, systemName, self.onConnectionChange, true);

	// Create the zone array
	for (var i = 1; i <= self.maxControllers; i++) {
		for (var j = 0; j < self.controller.numZones; j++) {
			self.zones["c"+i].push(new zone());
		}
	}

	// Create the sources array
	for (var i = 0; i <= self.controller.numSources; i++) {
		self.sources.push(new source());
	}
	
	
	*/
	
	
	self.XBMC = new XBMC_Controller(params);

	return self;
}

var XBMCMacMini;

CF.userMain = function() {
	XBMCMacMini = new XBMC_GUI({username: "xbmc", password: "xbmc", url: "192.168.0.100"});		//Home IP - Notebook
	//XBMCMacMini = new XBMC_GUI({username: "xbmc", password: "xbmc", url: "192.168.1.3"});		//Home IP - HTPC
	//XBMCMacMini = new XBMC_GUI({username: "xbmc", password: "xbmc", url: "192.168.168.201"});		//Office IP
	
	XBMCMacMini.setup();
};